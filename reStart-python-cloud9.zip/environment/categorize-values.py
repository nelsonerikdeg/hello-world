num= input('Ingrese numero:')
num=int(num)
num % 2 != 0
num.appear