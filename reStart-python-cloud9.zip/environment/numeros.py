m=int(input())
n=int(input())
c=int(n/m)
